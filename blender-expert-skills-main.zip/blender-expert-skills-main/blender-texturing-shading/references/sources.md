# Sources

Per-video notes live in the project's `notes/texturing/`; digests `_digest_snow_shading.md` and `_digest_texturing_pbr_painting.md`. The batch digest states that none of its experts gives albedo ranges, calls roughness the most important map, shows box projection or bakes procedurals; those parts of this skill are [added] or measured. URLs are `https://www.youtube.com/watch?v=<id>`.

## Julien Kaspar, Blender Studio: "Snow" stylized character shading lives (2021)

Credential: character artist at Blender Studio (Spring, Sprite Fright), author of the Stylized Character Workflow course and the free Rain rig. Blender 3.0 alpha on screen (Principled v1, EEVEE Legacy): values need the 5.2 translations in `expert-notes.md`. Auto captions, no frames.

| # | Id / URL | Length | Best for | Best timestamps |
|---|---|---|---|---|
| 1 | [0vGNOtX9iPk](https://www.youtube.com/watch?v=0vGNOtX9iPk) | 2:20 | base colours, black/white vertex-colour masks, judging colour honestly | 00:09:32 Diffuse Color + Standard; 01:03:33 mask layers; 01:19:25 vertex colours vs texture paint; 02:06:31 face vs vertex masking |
| 2 | [kN5aq1qXUCE](https://www.youtube.com/watch?v=kN5aq1qXUCE) | 2:22 | masks gating procedurals, lip streaks on a dedicated UV, fabric, bump Distance fix | 01:03:05 textures via masks; 01:23:24 bump Distance; 01:45:30 UV band masks; 01:56:20 weave direction on hems |
| 3 | [uTjfRGGV6ys](https://www.youtube.com/watch?v=uTjfRGGV6ys) | 2:02 | seam creases from strip UVs, painted 32-bit height, normalizing summed normals | 00:48:52 crossing masks; 00:55:37 painted height setup; 01:25:29 normalize for Cycles |
| 4 | [rKVeLjxZzTc](https://www.youtube.com/watch?v=rKVeLjxZzTc) | 2:22 | photo-texture pattern extraction, stitches, colour-variation map as mask | 00:02:47 blur + grain extract; 01:24:35 stitch group; 02:04:12 wash masks |
| 5 | [kAdgrBS4eDA](https://www.youtube.com/watch?v=kAdgrBS4eDA) | 2:02 | procedural eye, sclera, cornea, Mask modifier | 01:10:25 spherical gradient; 01:22:52 sclera tint; 01:41:28 cornea shaders; 01:48:26 pupil scale before bake |
| 6 | [D7kuKx7BV1A](https://www.youtube.com/watch?v=D7kuKx7BV1A) | 2:15 | skin SSS by anatomy, backlit test, pores in roughness, roughness zones, hair anisotropy | 00:12:43 SSS placement; 00:16:06 backlight rig; 00:24:31 SSS colour network; 01:00:38 pores in roughness; 01:26:22 roughness zones |
| 7 | [8GD1C9qLi-4](https://www.youtube.com/watch?v=8GD1C9qLi-4) | 2:28 | lookdev turntable, camera-ray world, hair streak painting through clumps | 00:22:52 turntable logic; 00:35:14 camera-ray world; 00:47:42 through-strokes; 01:09:34 Cycles anisotropy |
| F | [EDEMbeZfVcc](https://www.youtube.com/watch?v=EDEMbeZfVcc) | 2:08 | node-tree cleanup, clay/wire switch, bake recipe, presentation lighting | 00:06:04 cleanup; 00:15:26 clay switch; 00:31:58 bake setup; 01:36:11 samples for normals |

## Texturing course and texture-painting batch (`_digest_texturing_pbr_painting.md`)

| Expert / channel | Id / URL | Length, Blender | Best for | Best timestamps |
|---|---|---|---|---|
| Andrew Price, Blender Guru (founder of Poliigon, 9 years of scan capture) | [uHCJoNEWjXo](https://www.youtube.com/watch?v=uHCJoNEWjXo) | 1:53, 4.2 | realistic PBR wiring, normal OR displacement, displacement settings, masks, vertex-colour grime, Color Burn, decals, roughness edits | 00:21:29 Non-Color; 00:24:44 AO multiply; 00:29:57 normal vs displacement; 00:32:05 true displacement; 00:57:26 Noise Detail cost; 01:03:20 vertex colours vs image paint; 01:12:13 Color Burn; 01:24:02 decals; 01:30:11 roughness edits; 01:44:33 spalling |
| Grant Abbitt (GameDev.tv courses) | [7kSRXnAi7uA](https://www.youtube.com/watch?v=7kSRXnAi7uA) | 0:21, 5.1 | stylized hand-painted light with blend modes, unlit judging | 00:07:35 gradient fill; 00:10:18 Screen highlights; 00:12:27 unlit preview; 00:14:05 Multiply fill |
| Grant Abbitt | [_-zAhCOUpog](https://www.youtube.com/watch?v=_-zAhCOUpog) | 0:12, 4.3 | brush assets, screen projection limit, Mask stencil, custom brush asset | 00:02:13 screen projection; 00:07:38 erasing; 00:08:10 mask; 00:10:56 save asset |
| Grant Abbitt | [E29D9rS8op8](https://www.youtube.com/watch?v=E29D9rS8op8) | 0:05, 4.0 | setup: apply scale, margin 0.01, bleed 12 | 00:00:33; 00:04:21 |
| Grant Abbitt | [WjS_zNQNVlw](https://www.youtube.com/watch?v=WjS_zNQNVlw) | 0:03, 2.93 | island margin reasoning, save the image | 00:01:27; 00:02:50 |
| Ryan King Art (procedural material packs) | [5B244CYX1Tw](https://www.youtube.com/watch?v=5B244CYX1Tw) | 1:09, 2.93 | Object coordinates, metallic binary, Object Info Random, Pointiness, contrast before masking | 00:18:15; 00:40:12; 00:45:06; 01:00:03 |
| Ryan King Art | [4d4N8d4ki2Y](https://www.youtube.com/watch?v=4d4N8d4ki2Y) | 1:04, 2.9x | painted bump (0.5 grey), stencil photo brush | 00:44:43; 00:56:33 |
| Ryan King Art | [6jT4K0JpGNs](https://www.youtube.com/watch?v=6jT4K0JpGNs) | 0:27, 3.3 | paint setup checklist, stroke spacing and jitter | 00:04:36; 00:08:08; 00:18:59 |
| Surfaced Studio (tutorial and course channel) | [ywR8HsNeXQQ](https://www.youtube.com/watch?v=ywR8HsNeXQQ) | 0:44, 3.3 | Material slot mode, face-selection paint masks, texture vs mask, "cannot paint" checklist | 00:05:07; 00:17:09; 00:33:25; 00:42:03 |
| NoPoly (self-described non-expert) | [nQaUsgf9ZUg](https://www.youtube.com/watch?v=nQaUsgf9ZUg) | 0:25, 4.4 | UV vs Object coordinates, stretched-procedural axis limit | 00:07:21; 00:11:20 |
| YanSculpts | [kbyK_N65YEk](https://www.youtube.com/watch?v=kbyK_N65YEk) | 0:07, 2.7x | course trailer only; painted-skin layer order | 00:02:24 |

## Non-video references
- Blender 5.2 release notes (cached in `/Users/emmanuel/Developer/pro/2026-09-24 Blender Expert Skills/archive/tests/version-deltas/rn/5.2/`): Random Walk SSS rescaling (rendering.md, cycles.md), Principled Thin Wall.
- `sources/blender-version-deltas.md` sections 4, 8, 9, 10, 12 (texture paint, baking, materials, EEVEE, colour management).
- Albedo ranges (dielectric about sRGB 30 to 240, metal reflectance 180 to 255): common PBR guidance (Adobe Substance PBR guide), cited as [added], not re-verified against the guide in this build and not stated by any source video.
