# Sources (24 videos, 2 Blender Studio files)

Per-video notes with full timestamps: `notes/retopology/<id> - <title>.md`; batch digests: `_digest_snow_retopo_a.md`, `_digest_snow_retopo_b.md`, `_digest_speedchar_game_character.md`, `_digest_retopo_theory.md`; calibration: `_calibration_blender_studio_retopo.md`. Frame contact sheets for Kaspar's BCON22 talk: `frames/OLwtul3ngB8/sheet_01.jpg` to `sheet_11.jpg`.

## Film and animation retopology

| Expert, credential | Video | Best for | Best timestamps |
|---|---|---|---|
| Julien Kaspar, Blender Studio character artist (Spring, Sprite Fright, Rain and Snow rigs) | The Puzzle of "Good" Retopology, BCON22, 50:30, https://www.youtube.com/watch?v=OLwtul3ngB8 | the requirement map (six layers), articulation counts, style calibration (Rain, Snow, Rex, Anar), live start on the sheep character this skill is tested on | [00:07:55] map; [00:10:11] crease 1+2; [00:12:25] articulation; [00:13:32] expression bounds and landmarks; [00:20:16] realistic base mesh; [00:28:40] 2-pole aid; [00:43:49] poles; [00:44:59] local proximity loops; frames 00:22:53 (stack), 00:26:38 (subdiv 1/2), 00:34:08 (Solidify) |
| same | Snow Live #1, 2:16:32, https://www.youtube.com/watch?v=sXhIz-5g3Gc | setup, face order, mouth and eye articulation, creases, poles off creases | [00:11:32] Shrinkwrap Target Normal Project; [00:18:34] articulation; [00:22:38] mouth-corner 2-pole; [00:27:00] eye blocked closed; [00:36:27] poles; [01:31:00] duplicate and apply; [02:11:22] eyelid loops |
| same | Snow Live #2, 2:12:18, https://www.youtube.com/watch?v=tRqCeWZLqQo | loop budget out of the face, ear, neck, inner mouth, Shrinkwrap mask group, mirror-apply-bisect | [00:03:03] framing loop; [00:30:36] relax across the seam; [00:41:44] chin framing; [01:01:22] sharp edge without pole; [02:02:06] mask group |
| same | Snow Live #3, 2:34:00, https://www.youtube.com/watch?v=7xMRyBHeDBo | mesh hair shells, rim poles, bulge loops, bevel creases, triangles and n-gons, game vs film | [00:36:54] rim poles; [01:05:50] bulge loop; [01:18:27] lay out before bevelling; [01:29:22] tris/n-gons; [01:51:35] triangulate before baking |
| same | Snow Live #4, 2:11:54, https://www.youtube.com/watch?v=KWNcQZQkyjc | arms, fingers, hand loop reduction, separate objects, his five quality criteria | [00:06:54] 8-vertex arm ring; [00:08:01] 3 loops per joint; [00:35:53] linked-duplicate fingers; [00:58:52] criteria; [01:27:33] ring mismatch; [01:30:37] diamonds on the back of the hand |
| same | Snow Live #5, 2:22:00, https://www.youtube.com/watch?v=8ljpBjgIST0 | hands, legs, merge by counts, two Shrinkwraps, Multires Apply Base | [00:33:59] hand 18 vs arm 11; [00:56:06] two Shrinkwraps by vertex group; [01:37:48] joints; [02:06:31] bridge and slide; [02:09:01] Apply Base |
| same | Snow Live #6, 2:03:08, https://www.youtube.com/watch?v=8UqpNwkTEXA | post Apply Base volume pass, rebuilding sharp edges, naming, shirt from body | [00:14:27] deflate to the skin; [00:20:08] never re-shrinkwrap; [00:25:33] rebuild sharp loops; [00:39:00] softer creases; [01:33:34] shirt base |
| same | Snow Live #7, 2:14:06, https://www.youtube.com/watch?v=EBet5sIZcKY | cloth folds, 6-pole to 5-3-5, split for asymmetry, clothing Shrinkwrap Project + Limit | [00:08:54] crease pair by bevel; [00:11:41] valence rule; [00:32:03] split object; [00:48:52] Project + Limit; [01:23:34] no spirals |
| same | Snow Finale, 2:02:58, https://www.youtube.com/watch?v=FnTOVcPaWV8 | triangle pairs in folds, intersections, inner bands, handoff list | [00:28:32] triangle pairs; [01:04:16] adjacent diamonds; [01:47:58] no intersections; [01:49:42] inner band; [01:56:19] handoff; [01:58:41] cage-level check |
| Jonathan Lampel, CG Cookie instructor, RetopoFlow project manager | Building Good Topology and Retopology, BCON24, 50:29, https://www.youtube.com/watch?v=PAK5zQONgvs | why poles pinch (density), tris and n-gons as tools, holding edges, junctions, low-poly edge test | [00:09:05] auto only for static; [00:12:45] Triangulate before export; [00:21:18] density; [00:23:00] Optimal Display off; [00:30:34] double smooth; [00:32:18] junctions; [00:34:32] every edge has a job; [00:40:04] flexible areas |
| Vilem Duha, BlenderKit co-founder, 20+ years in Blender | A New Approach to Retopology, BCON23, 16:35, https://www.youtube.com/watch?v=7AR9-LxY6AQ | fit the subdivided surface instead of snapping the cage | [00:07:18] the error; [00:08:24] offset makes cavities worse; [00:08:58] inverse subdivision; [00:11:15] iterative; [00:11:48] where to add loops |
| Dikko, character artist and rigger | Modeling for Animation 06: Retopologising the Face, 52:16, https://www.youtube.com/watch?v=SwM19PgSdCM | pole-by-pole face map, five eye poles, equal spans, centre line, mouth bag, head-to-neck join | [00:01:28] five poles; [00:04:16] 10/10 spans; [00:04:49] no spirals, centre line; [00:27:42] back-of-head fill; [00:41:46] mouth bag; [00:49:12] neck collapse |
| Dikko | ULTIMATE Character Modelling Part 7: Retopo of the Body, 1:31:15, https://www.youtube.com/watch?v=3WnW_ZFXudk | body core loops, shoulder and hip caps, span counts, routing spans | [00:01:51] chest and hip loops; [00:13:47] arm spans; [00:26:03] bevel at the pole; [00:31:22] routing; [01:04:04] collapse over add; [01:16:41] leg 18 |

## Game low poly

| Expert, credential | Video | Best for | Best timestamps |
|---|---|---|---|
| Nikolay Naydenov (SpeedChar), character artist at Gameloft Bulgaria (Heroes of the Dark) | ep23 Starting the Low Poly, 51:31, https://www.youtube.com/watch?v=6MccOhJZXPQ | budgets, exploding for the bake, silhouette-only surrounding, fingers | [00:01:06] explode; [00:09:58] head vs body budget; [00:24:13] no Shrinkwrap on very low poly; [00:34:02] silhouette; [00:34:34] face 3x density; [00:50:07] unique UVs where AO differs |
| same | ep24 Left Hand Retopology, 51:10, https://www.youtube.com/watch?v=YL2oRj3NGuY | where triangles are fine, slivers, diagonal control, hand budget | [00:00:32] triangles; [00:03:06] cut the diagonal; [00:11:06] rigid parts; [00:46:36] big flat polygons; [00:50:34] hands budget |
| same | ep25 Head Retopology 01, 57:58, https://www.youtube.com/watch?v=TYjlg5ilozg | game head loops only for animation, symmetry, cavities | [00:01:08] rotate around the mouth; [00:04:29] split asymmetric parts; [00:10:24] under-eye loop; [00:14:39] follow planes; [00:39:02] ear cavity |
| same | ep26 Head Retopology 02, 50:46, https://www.youtube.com/watch?v=PsOBC6cpomk | edit the high for the low, front vs back fidelity, final head count | [00:02:17] edit the high; [00:04:25] front vs back; [00:10:28] triangles where nothing moves; [00:33:24] 2,600 tris; [00:48:55] symmetrize the high |
| same | ep35 Adjusting the Low Poly, 36:50, https://www.youtube.com/watch?v=EnzdtZnBigE | fitting pass, manual triangulation, final count | [00:06:30] 12,000 tris; [00:10:18] triangulate twisted quads; [00:18:44] fitting pass; [00:21:30] slightly proud |
| On Mars 3D (in notes/uv-baking) | 5 Tips to Master Texture Bakes, https://www.youtube.com/watch?v=C_RqdNbYOjE | every hard edge is a UV seam | [00:08:04] |

## Setup, tools and beginner-level confirmations

| Expert, credential | Video | Best for | Best timestamps |
|---|---|---|---|
| Jamie Dunbar, character artist, author of "Character Design for Production" | Retopology with Poly Build, 24:14, https://www.youtube.com/watch?v=l-sALvdn3FI | Shrinkwrap failure modes, no bumps in topology, subdiv off while building | [00:05:22] both directions; [00:06:17] normals; [00:15:09] popping fix; [00:17:15] bumps go to maps; [00:22:19] no subdiv while building |
| Zach Reinhardt (CG Boost) | Retopology in Blender beginner tutorial, 14:14, https://www.youtube.com/watch?v=X2GNyEUvpD4 | snapping vs Shrinkwrap, important loops first unconnected, finalize order | [00:07:02] view-angle trap; [00:08:04] Shrinkwrap catches loop cuts; [00:09:36] loops first; [00:13:01] finalize |
| Grant Abbitt, Blender educator (GameDev.tv) | Retopology Guide Part 1: Setup, 8:44, https://www.youtube.com/watch?v=6sE-p8PcHDo | budget example, apply rotation before mirroring | [00:00:31] 4 M to 3.5k tris; [00:04:19] apply rotation |
| Grant Abbitt | Retopologise a Face, 7:24, https://www.youtube.com/watch?v=C249AnzAI40 | critique of auto retopo, flows first, poles where flows meet | [00:00:32] auto critique; [00:04:28] flows first; [00:05:22] poles |
| Ryan King, Blender educator | Retopology for Beginners, 21:51, https://www.youtube.com/watch?v=1myOZaxtHes | mirror selection trap, tri better than 5-gon, edge on the crease, backup before apply | [00:07:37]; [00:14:04]; [00:15:41]; [00:18:39] |
| Kenny Praise (Kenny's Arts) | Retopology for Beginners, 22:40, https://www.youtube.com/watch?v=7XdbJX8roCg | five flows drawn first, relax after each block, equal counts | [00:00:35]; [00:03:51]; [00:11:00] |

## Ground truth files (CC-BY, Blender Studio)

From https://studio.blender.org/blog/live-retopology-at-bcon22/ : `/Users/emmanuel/Developer/pro/2026-09-24 Blender Expert Skills/tests/fixtures/retopo_examples.blend` and `retopo_demo.blend` (Rex, Snow, Rain, stylized heads, hand, sheep), measured with bx_audit in `_calibration_blender_studio_retopo.md`. Test fixtures cut from them: `sheep_sculpt.blend` (input) and `sheep_reference_retopo.blend` (Kaspar's retopology of the sheep, used only for numbers).
